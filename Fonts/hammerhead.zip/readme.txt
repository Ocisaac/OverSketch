This font is free for personal use only, if you want the unlimited commercial license, send me an email to: hammerheadfont@outlook.it 

Regards

Davide Lasagni
